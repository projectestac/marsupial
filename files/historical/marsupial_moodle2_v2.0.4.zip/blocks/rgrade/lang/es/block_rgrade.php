<?php
$string['pluginname'] = 'Calificaciones contenidos remotos';
$string['rgrade'] = 'Calificaciones contenidos remotos';
$string['all_groups'] = 'Todos los grupos';
$string['go'] = 'Accede';
$string['book'] = 'Libro';
$string['group'] = 'Grupo';
$string['error_saving_grade'] = 'Ha ocurrido un error y no se ha podido salvar el intento $a->attempt del Usuario (Id: $a->id).';
$string['alert_units_table'] = "Los datos que se visualizan corresponden a los de las dos últimas unidades para las que ha habido actividad. Para seleccionar una/s otra/s, hay que usar el selector de unidades.";
$string['alert_units_table_hide'] = "No quiero volver a ver el aviso.";
$string['alert_units_table_ok'] = 'Acepta';
