<?php
$string['rgrade'] = 'Qualificacions continguts remots';
$string['all_groups'] = 'Tots els grups';
$string['go'] = 'Accedeix';
$string['book'] = 'Llibre';
$string['group'] = 'Grup';
$string['error_saving_grade'] = 'S\'ha produït un error i no s\'ha pogut salvar l\'intent $a->attempt de l\'usuari (Id: $a->id).';
$string['alert_units_table'] = "Les dades que es visualitzen corresponen a les de les dues darreres unitats per a les quals hi ha hagut activitat. Per a seleccionar-ne una/es altra/es, cal usar el selector d'unitats.";
$string['alert_units_table_hide'] = "No vull tornar a veure l'avís.";
$string['alert_units_table_ok'] = 'Accepta';