<?php
$string['rgrade'] = 'Remote contents\' grades';
$string['all_groups'] = 'All groups';
$string['go'] = 'Go';
$string['book'] = 'Book';
$string['group'] = 'Group';
$string['error_saving_grade'] = 'There was an error and failed to save the user attempt $a->attempt (Id: $a->id).';
$string['alert_units_table'] = "The data displayed correspond to the last two units for which there has been activity. To select other use the units selector.";
$string['alert_units_table_hide'] = "I don't want to see the notice again.";
$string['alert_units_table_ok'] = 'Accept';