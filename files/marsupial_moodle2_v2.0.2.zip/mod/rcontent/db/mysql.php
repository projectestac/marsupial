<?php // $Id: mysql.php,v 1.33 2006/10/26 22:39:14 stronk7 Exp $

// THIS FILE IS DEPRECATED!  PLEASE DO NOT MAKE CHANGES TO IT!
//
// IT IS USED ONLY FOR UPGRADES FROM BEFORE MOODLE 1.7, ALL 
// LATER CHANGES SHOULD USE upgrade.php IN THIS DIRECTORY.

function rcontent_upgrade($oldversion) {
/// This function does anything necessary to upgrade
/// older versions to match current functionality
    global $CFG;

    return true;
}
?>
