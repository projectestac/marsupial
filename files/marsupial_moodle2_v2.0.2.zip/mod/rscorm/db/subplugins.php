<?php

$subplugins = array('rscormreport'=>'mod/rscorm/report');
