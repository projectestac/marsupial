<?php
  /////////////////////////////////////////////////////////////////////////////////
  ///  Code fragment to define the version of rscorm                             //
  ///  This fragment is called by moodle_needs_upgrading() and /admin/index.php  //
  /////////////////////////////////////////////////////////////////////////////////
  
  /**
   *  Developed for Moodle version 1.9.5 
   */

  $module->version = 2012092191;    // The (date) version of this module
  $module->requires = 2007101509;   // The version of Moodle that is required
  
?>
