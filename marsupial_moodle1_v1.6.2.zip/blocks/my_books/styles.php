

#blocks-my_books-manageKey table, #blocks-my_books-manageKey table th, #blocks-my_books-manageKey table td{
	border: 1px solid #999;
}
