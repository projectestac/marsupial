.import-alert{
    color: #FF9933;
}

.import-alert{
    color: #FF9933;
}

#block-block_rcommon .info{
	float:none; 
	width: 90%; 
	margin: auto auto;
}

#block-block_rcommon div.right{
	float: right;
	margin: 10px 0;
}

.center{
	width: 90%;
	text-align: center;
}

#block-block_rcommon table, #block-block_rcommon table th, #block-block_rcommon table td{
	border: 1px solid #999;
}

#block-block_rcommon table{
	clear: both;
}

#block-block_rcommon table th{
	text-align: center;
	background-color: #DDD;
}

#block-block_rcommon .error{
}

#block-block_rcommon .alert{
	
}
