<?PHP 

// MARSUPIAL *********** AFEGIT -> Publishers manager
// 2011.09.06 @mmartinez
$string['addnewpublisher'] = 'A&ntilde;adir nuevo proveedor';
// *********** FI
$string['centernotfound'] = "C&oacute;digo de centro (CFG->center) no encontrado en config.php";
// MARSUPIAL *********** AFEGIT -> Publishers manager
// 2011.09.06 @mmartinez
$string['code'] = 'C&oacute;digo';
$string['confirmdeletestr'] = 'Est&acute; seguro que quiere borrar el proveedor de contenidos:<br/>$a?';
// *********** FI
$string['consumeerror'] = 'Ocurrio alg&uacute;n error durante el proceso.';
$string['consumefinish'] = 'Proceso finalizado correctamente.';
$string['consumetitle'] = 'Descargador de la estructura de libros';
$string['consumewait'] = 'Descargando, el proceso puede durar unos minutos, por favor espere...';
// MARSUPIAL *********** AFEGIT -> Publishers manager
// 2011.09.06 @mmartinez
$string['delok'] = 'Datos borrados correctamente';
$string['delko'] = 'No ha sido possible borrar los datos, por favor vuelva a intentarlo m&acute;s tarde';
// *********** FI
$string['downloadbookstructures'] = 'Descargar estructura de libros';
$string['error_authentication'] = 'Error de autenticaci&oacute;n, c&oacute;digo: ';
$string['error_code_0'] = 'Error inesperado.';
$string['error_code_-1'] = 'Error al realizar la URL din&aacute;mica.';
$string['error_code_-2'] = 'El c&oacute;digo de licencia no es v&aacute;lido.';
$string['error_code_-3'] = 'El Isbn del producto no es v&aacute;lido.';
$string['error_code_-4'] = 'La licencia ha expirado.';
$string['error_code_-101'] = 'Autenticaci&oacute;n incorrecta. El usuario que solicita acceso a este
m&eacute;todo del servicio Web no es correcto.';
$string['error_code_-102'] = 'Autenticaci&oacute;n incorrecta. El usuario que solicita acceso a este
m&eacute;todo del servicio Web no tiene permisos suficientes.';
$string['exit'] = 'Salir';
// MARSUPIAL ********** AFEGIT -> Insert form key
//2011.10.24 @mmartinez
$string['insertkeybtn'] = 'A�ade la clave';
$string['insertkeymsg'] = 'Introduce una clave para este recurso';
// ********** FI
// MARSUPIAL ********** AFEGIT -> Keys manager
//2011.09.19 @mmartinez
$string['key'] = 'Clave';
$string['keyadd'] = 'A�adir la clave';
$string['keyaddformexception'] = 'Has dejado el formulario incompleto! Todos los campos son obligatorios.';
$string['keyaddingforuser'] = 'A&ntilde;adiendo una clave para el usuario/a';
$string['keyconfirmdelete'] = 'Seguro que quieres eliminar esta clave?';
$string['keydelbtn'] = 'Eliminar';
$string['keymanager'] = 'Administraci�n de claves de los usuarios';
$string['keymanagerexportbtn'] = 'Exporta las claves de todos los usuarios en una hoja de c&acute;lculo';
$string['keysadminsearchuserbtn'] = 'Gestionar las claves';
$string['keyslookupusertext'] = 'Escoge un usuario/a para gestionar sus claves';
$string['keysshowingfor'] = 'Gestiona las claves del usuario/a';
// *********** FI
$string['loading'] = 'Descargando, por favor espere...';
// MARSUPIAL *********** AFEGIT -> Insert form key
// 2011.10.24 @mmartinez
$string['nokeybtn'] = 'No tengo ninguna clave';
// *********** FI
// MARSUPIAL *********** AFEGIT -> Publishers manager
// 2011.09.06 @mmartinez
$string['manage'] = 'Gestionar';
// *********** FI
$string['noactivity'] = 'Actividad no encontrada.';
$string['nobooks'] = 'No se han recibido libros';
$string['nobookid'] = 'Libro no encontrado.';
$string['nocredentials'] = 'Credenciales no encontradas.';
$string['nopublisher'] = 'Editor no encontrado.';
$string['nounit'] = 'Unidad no encontrada.';
// MARSUPIAL *********** AFEGIT -> Publishers manager
// 2011.09.06 @mmartinez
$string['publishersmanager'] = 'Gesti&oacute;n de proveedores de contenidos';
// *********** FI
$string['rcommon'] = 'Recursos remotos';
// MARSUPIAL *********** AFEGIT -> Publishers manager
// 2011.09.06 @mmartinez
$string['save'] = 'Guardar';
$string['saveok'] = 'Saved correctly';
$string['saveko'] = 'No ha estat possible desar les dades, si us plau torni a intentar-ho';
$string['savekoemptyvalues'] = 'No ha estat possible desar les dades, almenys el camp codi s\'ha d\'omplir.';
// *********** FI
// MARSUPIAL *********** AFEGIT -> Publishers manager
// 2011.09.06 @mmartinez
$string['selectpublisher'] = 'Seleccione un proveedor de contenidos...';
$string['selectpublisherdescription'] = 'To download all the book structures it is necessary to select a publisher';
$string['selectpublisheredit'] = 'Seleccione un proveedor de contenidos para editar sus datos';
// *********** FI
//MARSUPIAL ********** AFEGIT -> Text string for students roles settings
//2011.05.16 @mmartinez
$string['teacherroles'] = 'Roles profesor';
$string['teacherrolesinfo'] = 'Roles que se autenticar&aacute;n en las editoriales como usuario profesor. El resto se autenticar&aacute;n como estudiante';
//********** FI
$string['urlmoreinfo'] = 'Para m&aacute;s informaci&oacute;n: <a href="$a" target="_blank">click aqu&iacute;</a>';
// MARSUPIAL *********** AFEGIT -> Publishers manager
// 2011.09.06 @mmartinez
$string['urlwsauthentication'] = 'Direcci&oacute;n del servicio web de autenticaci&oacute;n';
$string['urlwsbookstructure'] = 'Direcci&oacute;n del servicio web de estructura de libro';
//********** FI
// MARSUPIAL ********** AFEGIT -> Keys manager
//2011.09.19 @mmartinez
$string['userhasnokeys'] = 'Este usuario/a no tiene claves registradas';
$string['usernotfound'] = 'Usuario/a inv&acute;lido o inexistente';
//*************** FI
//MARSUPIAL ************ AFEGIT - Strings of the options in the admin block
//2011.09.15 @sarjona
$string['marsupialcontent'] = 'Contenidos';
$string['marsupialusersync'] = 'Sincronizar con &Agrave;tria';
$string['marsupialupdate_publisher'] = 'Actualizar proveedores';
$string['marsupialmanage_publisher'] = 'Administrar proveedores';
$string['marsupialpublisher'] = 'Proveedores';
$string['marsupialcredentials'] = 'Credenciales';
$string['marsupialget_credentials'] = 'Actualizar credenciales';
$string['marsupialmanage_credentials'] = 'Administrar credenciales';
$string['scorm'] = 'SCORM remoto';
$string['webcontent'] = 'Contenido remoto';
$string['downloadbookstructures_warning'] = '<b>ATENCI&Oacute;N</b>: Se est&aacute; descargando la estructura de los libros. Este proceso puede llevar algunos minutos. Por favor, espere...';
//*************** FI

//XTEC ************ AFEGIT - Marsupial Stats
//2011.10.21 @fcasanel
$string['marsupialstats'] 		= 'Estado de Marsupial';
$string['atria_connection'] 		= 'Conexión con Atria';
$string['atria_connection_ok'] 		= 'La conexión con Atria es correcta';
$string['atria_connection_ko'] 		= 'La conexión con Atria provoca el siguiente error:';
$string['user_credentials'] 		= 'Usuarios/as con credenciales';
$string['users_proportion'] 		= '$a->with_credentials de los $a->total_users usuarios del sistema disponen de alguna credencial';
$string['show_users'] 			= 'Mostrar usuarios';
$string['publishers'] 			= 'Proveedores';
$string['publishers_and_books'] 	= 'A continuación se muestran los proveedores y el número de libros disponibles';
$string['no_publishers'] 		= 'No existen proveedores disponibles';
$string['without_credentials'] 		= 'Usuarios sin credenciales';
$string['with_credentials'] 		= 'Usuarios con credenciales';
$string['back_to_stats'] 		= 'Vuelve a la portada';
$string['good_connection'] 		= 'Conexión correcta';
$string['bad_connection'] 		= 'Se ha producido un problema con la conexión';
$string['books'] 			= 'libros';
$string['atria_error_information'] 	= 'Posiblemente el error de conexión con Atria sea causado porque todavía no se ha sincronizado ningún usuario';
$string['check_publishers'] 		= 'Comprobar la conexión';
$string['wait_please'] 			= 'Esta operación puede tardar unos minutos';
$string['marsupial_bookswarning']       = '<b>AVISO</b>: Si despu&eacute;s de actualizar la lista de libros detecta que falta alguno, contacte con su proveedor de contenidos.';
//************ FI
?>