<?PHP 

// MARSUPIAL *********** AFEGIT -> Publishers manager
// 2011.09.06 @mmartinez
$string['addnewpublisher'] = 'Afegeix nou prove&iuml;dor';
// *********** FI
$string['centernotfound'] = 'Codi de centre (CFG->center) no trobat al fitxer de configuraci&oacute; (config.php)';
// MARSUPIAL *********** AFEGIT -> Publishers manager
// 2011.09.06 @mmartinez
$string['code'] = 'Codi';
$string['confirmdeletestr'] = 'Est&agrave; segur/a que vol esborrar el prove&iuml;dor de continguts <b>\'$a\'</b>?';
// *********** FI
$string['consumeerror'] = 'S\'ha produ&iuml;t algun error durant el proc&eacute;s';
$string['consumefinish'] = 'Proc&eacute;s finalitzat correctament.';
$string['consumetitle'] = 'Desc&agrave;rrega de l\'estructura dels llibres dels prove&iuml;dors de continguts';
$string['consumewait'] = 'Descarregant l\'estructura dels llibres. <br>Aquest proc&eacute;s pot portar alguns minuts.<br>Si us plau, esperi...';
// MARSUPIAL *********** AFEGIT -> Publishers manager
// 2011.09.06 @mmartinez
$string['delok'] = 'Dades esborrades correctament';
$string['delko'] = 'No ha estat possible esborrar les dades, si us plau torni a intentar-ho pasats uns minuts';
// *********** FI
$string['downloadbookstructures'] = 'Descarrega/actualitza l\'estructura dels llibres';
$string['error_authentication'] = 'Error d\'autenticaci&oacute, codi: ';
$string['error_code_0'] = 'Error inesperat.';
$string['error_code_-1'] = 'Error al realitzar la URL din&agrave;mica.';
$string['error_code_-2'] = 'El codi de llicencia no es v&agrave;lid.';
$string['error_code_-3'] = 'El Isbn del producte no es v&agrave;lid.';
$string['error_code_-4'] = 'La llicencia ha expirat.';
$string['error_code_-101'] = 'Autenticaci&oacute; incorrecta. L\'usuari que sol&middot;licitat acc&eacute;s a aquest
m&egrave;tode del servei web no es correcte.';
$string['error_code_-102'] = 'Autenticaci&oacute; incorrecta. L\'usuari que sol&middot;licita acc&eacute;s a aquest
m&egrave;tode del servei web no te permisos suficients.';
$string['exit'] = 'Surt';
// MARSUPIAL ********** AFEGIT -> Keys manager
//2011.09.19 @mmartinez
$string['key'] = 'Clau';
$string['keyadd'] = 'Afegeix la clau';
$string['keyaddformexception'] = 'Has deixat el formulari incomplert! Tots els camps són obligatoris.';
$string['keyaddingforuser'] = 'Afegint una clau per a l\'usuari/ària';
$string['keyconfirmdelete'] = 'Segur que vols eliminar aquesta clau?';
$string['keydelbtn'] = 'Elimina';
$string['keymanager'] = 'Administraci&oacute; de claus dels usuaris';
$string['keymanagerexportbtn'] = 'Exporta les claus de tots el usuaris en un full de càlcul';
$string['keysadminsearchuserbtn'] = 'Gestiona les claus';
$string['keyslookupusertext'] = 'Escull un usuari/ària per gestionar les seves claus';
$string['keysshowingfor'] = 'Gestiona les claus de l\'usuari/&agrave;ria';
// *********** FI
$string['loading'] = 'Descarregant. Si us plau esperi...';
// MARSUPIAL *********** AFEGIT -> Publishers manager
// 2011.09.06 @mmartinez
$string['manage'] = 'Gestionar';
// *********** FI
$string['noactivity'] = 'Activitat no trobada';
$string['nobooks'] = 'No s\'ha rebut cap llibre';
$string['nobookid'] = 'Llibre no trobat';
$string['nocredentials'] = 'Credencials per accedir al llibre no trobades';
$string['nopublisher'] = 'Prove&iuml;dor de continguts no trobat';
$string['nounit'] = 'Unitat no trobada';
// MARSUPIAL *********** AFEGIT -> Publishers manager
// 2011.09.06 @mmartinez
$string['publishersmanager'] = 'Gesti&oacute; de prove&iuml;dors de continguts';
// *********** FI
$string['rcommon'] = 'Recursos remots';
// MARSUPIAL *********** AFEGIT -> Publishers manager
// 2011.09.06 @mmartinez
$string['save'] = 'Desa';
$string['saveok'] = 'Dades desades correctament';
$string['saveko'] = 'No ha estat possible desar les dades, si us plau torni a intentar-ho';
$string['savekoemptyvalues'] = 'No ha estat possible desar les dades, almenys el camp codi s\'ha d\'omplir.';
// *********** FI
// MARSUPIAL *********** AFEGIT -> Publishers manager
// 2011.09.06 @mmartinez
$string['selectpublisher'] = 'Seleccioneu un prove&iuml;dor de continguts...';
$string['selectpublisheredit'] = 'Seleccioneu un prove&iuml;dor de continguts per editar les seves dades';
$string['selectpublisherdescription'] = 'Per descarregar totes les estructures de llibre &eacute;s necessari seleccionar un editor';
// *********** FI
//MARSUPIAL ********** AFEGIT -> Text string for students roles settings
//2011.05.16 @mmartinez
$string['teacherroles'] = 'Rols del professorat';
$string['teacherrolesinfo'] = 'Rols que s\'autenticaran a les editorials com a usuari professor/a. La resta s\'autenticaran com a estudiants';
//********** FI
$string['urlmoreinfo'] = 'Per a m&eacute;s informaci&oacute;: <a href="$a" target="_blank">click aqu&iacute;</a>';
// MARSUPIAL *********** AFEGIT -> Publishers manager
// 2011.09.06 @mmartinez
$string['urlwsauthentication'] = 'Adre&ccedil;a del servei web d\'autenticaci&oacute;';
$string['urlwsbookstructure'] = 'Adre&ccedil;a del servei web d\'estructura de llibre';
//********** FI
// MARSUPIAL ********** AFEGIT -> Keys manager
//2011.09.19 @mmartinez
$string['userhasnokeys'] = 'Aquest usuari/&agrave;ria no te claus registrades';
$string['usernotfound'] = 'Usuari/&agrave;ria inv&agrave;lid o inexistent';
//*************** FI
//MARSUPIAL ************ AFEGIT - Strings of the options in the admin block
//2011.08.02 @fcasanel
$string['marsupialcontent'] = 'Continguts';
$string['marsupialusersync'] = 'Sincronitza amb &Agrave;tria';
$string['marsupialupdate_publisher'] = 'Actualitza prove&iuml;dors';
$string['marsupialmanage_publisher'] = 'Administra prove&iuml;dors';
$string['marsupialpublisher'] = 'Prove&iuml;dors';
$string['marsupialcredentials'] = 'Credencials';
$string['marsupialget_credentials'] = 'Actualitza credencials';
$string['marsupialmanage_credentials'] = 'Administra credencials';
$string['scorm'] = 'SCORM remot';
$string['webcontent'] = 'Contingut remot';
$string['downloadbookstructures_warning'] = '<b>ATENCI&Oacute;</b>: S\'est&agrave; descarregant l\'estructura dels llibres. Aquest proc&eacute;s pot trigar alguns minuts. Si us plau, esperi...';
//*************** FI

?>