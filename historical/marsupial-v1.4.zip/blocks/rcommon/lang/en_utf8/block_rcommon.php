<?PHP 

// MARSUPIAL *********** AFEGIT -> Publishers manager
// 2011.09.06 @mmartinez
$string['addnewpublisher'] = 'Add new publisher';
// *********** FI
$string['centernotfound'] = 'Code center (CFG->center) not found in config.php';
// MARSUPIAL *********** AFEGIT -> Publishers manager
// 2011.09.06 @mmartinez
$string['code'] = 'Code';
$string['confirmdeletestr'] = 'Are you sure you want to delete the publisher:<br/>$a?';
// *********** FI
$string['consumeerror'] = 'Some error ocurred during the process';
$string['consumefinish'] = 'Process finish correctly.';
$string['consumetitle'] = 'Books Structure downloader';
$string['consumewait'] = 'Running the downloader, this process may take some time, please wait...';
// MARSUPIAL *********** AFEGIT -> Publishers manager
// 2011.09.06 @mmartinez
$string['delok'] = 'Data removed successfully';
$string['delko'] = 'Unable to delete the data, please try again a few minutes later';
// *********** FI
$string['downloadbookstructures'] = 'Download books structures';
$string['error_authentication'] = 'Authentication error: Code: ';
$string['error_code_0'] = 'Unexpected error.';
$string['error_code_-1'] = 'Failed to make the dynamic URL.';
$string['error_code_-2'] = 'The license code is invalid.';
$string['error_code_-3'] = 'The product Isbn is not valid.';
$string['error_code_-4'] = 'The license has expired.';
$string['error_code_-101'] = 'Incorrect authentication. The user requesting access to this
Web service method is not correct.';
$string['error_code_-102'] = 'Incorrect authentication. The user requesting access to this
web service method has insufficient permissions.';
$string['exit'] = 'Exit';
// MARSUPIAL ********** AFEGIT -> Keys manager
//2011.09.19 @mmartinez
$string['key'] = 'Key';
$string['keyadd'] = 'Add the key';
$string['keyaddformexception'] = 'You left incomplete form! All fields are required.';
$string['keyaddingforuser'] = 'Adding a key to the user';
$string['keyconfirmdelete'] = 'Are you sure you want to delete this key?';
$string['keydelbtn'] = 'Delete';
$string['keymanager'] = 'Users key management';
$string['keymanagerexportbtn'] = 'Export the keys of all users in a spreadsheet';
$string['keysadminsearchuserbtn'] = 'Managing keys';
$string['keyslookupusertext'] = 'Choose a user to manage his keys';
$string['keysshowingfor'] = 'Manage key of user';
// *********** FI
$string['loading'] = 'Loading, please wait...';
// MARSUPIAL *********** AFEGIT -> Publishers manager
// 2011.09.06 @mmartinez
$string['manage'] = 'Manage';
// *********** FI
$string['noactivity'] = 'Activity not found.';
$string['nobooks'] = 'No books received';
$string['nobookid'] = 'Book not found.';
$string['nocredentials'] = 'Credentials not found.';
$string['nopublisher'] = 'Publisher not found.';
$string['nounit'] = 'Unit not found.';
// MARSUPIAL *********** AFEGIT -> Publishers manager
// 2011.09.06 @mmartinez
$string['publishersmanager'] = 'Publishers management';
// *********** FI
$string['rcommon'] = 'Remote resource manager';
// MARSUPIAL *********** AFEGIT -> Publishers manager
// 2011.09.06 @mmartinez
$string['save'] = 'Save';
$string['saveok'] = 'Saved correctly';
$string['saveko'] = 'Unable to save data, please try again';
$string['savekoemptyvalues'] = 'Unable to save data, at least the field code must be completed.';
// *********** FI
// MARSUPIAL *********** AFEGIT -> Publishers manager
// 2011.09.06 @mmartinez
$string['selectpublisher'] = 'Select a publisher...';
$string['selectpublisherdescription'] = 'To download all the book structures it is necessary to select a publisher';
$string['selectpublisheredit'] = 'Select a publisher to edit his info';
// *********** FI
//MARSUPIAL ********** AFEGIT -> Text string for students roles settings
//2011.05.16 @mmartinez
$string['teacherroles'] = 'Teacher roles';
$string['teacherrolesinfo'] = 'Roles that will be authenticated as a teacher. The rest will be authenticated as a student';
//********** FI
$string['urlmoreinfo'] = 'For more information: <a href="$a" target="_blank">click here</a>';
// MARSUPIAL *********** AFEGIT -> Publishers manager
// 2011.09.06 @mmartinez
$string['urlwsauthentication'] = 'Authentication web services address';
$string['urlwsbookstructure'] = 'Book structure web services address';
//********** FI
// MARSUPIAL ********** AFEGIT -> Keys manager
//2011.09.19 @mmartinez
$string['userhasnokeys'] = 'This user has no key registered';
$string['usernotfound'] = 'User invalid or nonexistent';
//*************** FI
//
//MARSUPIAL ************ AFEGIT - Strings of the options in the admin block
//2011.09.15 @sarjona
$string['marsupialcontent'] = 'Contents';
$string['marsupialusersync'] = 'Synchronize with &Agrave;tria';
$string['marsupialupdate_publisher'] = 'Update suppliers';
$string['marsupialmanage_publisher'] = 'Manage suppliers';
$string['marsupialpublisher'] = 'Suppliers';
$string['marsupialcredentials'] = 'Credentials';
$string['marsupialget_credentials'] = 'Update credentials';
$string['marsupialmanage_credentials'] = 'Manage credentials';
$string['scorm'] = 'Remote SCORM';
$string['webcontent'] = 'Remote content';
$string['downloadbookstructures_warning'] = '<b>ATENTION</ b>: You are trying to download the structure of books. This process can take several minutes. Please wait  ...';
//*************** FI
?>