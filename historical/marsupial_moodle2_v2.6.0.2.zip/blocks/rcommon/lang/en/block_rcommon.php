<?PHP
$string['pluginname'] ='Remote resources [Erase me after upgrade and do not install me]';