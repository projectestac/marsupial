<?php
// XTEC ********** ADDED -> Spanish text string for my_books block

$string['activitytypeopen'] = 'C&oacute;mo se ha de abrir la actividad';
$string['activitytypeopeninfo'] = 'C&oacute;mo quieres que se le abra al alumno la actividad';
$string['directories'] = 'Mostrar enlaces de directorio';
$string['directoriesinfo'] = 'Las ventanas \"popup\", ¿deben por defecto mostrar los enlaces del directorio?';
$string['error_loading_data'] = 'Error al cargar datos. Por favor pongase en contacto con el administrador.';
$string['height'] = 'Alto';
$string['heightinfo'] = 'Esta preferencia determina la altura por defecto del marco o ventana';
$string['location'] = 'Mostrar la barra de ubicación';
$string['locationinfo'] = 'Las ventanas \"popup\", ¿deben por defecto mostrar la barra de ubicación?';
$string['menubar'] = 'Mostrar la barra de menú';
$string['menubarinfo'] = 'Las ventanas \"popup\", ¿deben por defecto mostrar la barra de menú?';
$string['my_books'] = 'Mis libros';
$string['nobooks'] = 'No hay ning&uacute;n libro para mostrar';
$string['popup'] = 'Ventana nueva';
$string['popupconfig'] = 'Configuraci&oacute;n de la nueva ventana de actividad';
$string['resizable'] = 'Permitir el cambio de tamaño de la ventana';
$string['resizableinfo'] = 'Las ventanas \"popup\", ¿deben por defecto ser redimensionables?';
$string['samewindow'] = 'Misma ventana';
$string['scrollbars'] = 'Permitir desplazamiento de la ventana';
$string['scrollbarsinfo'] = 'Las ventanas \"popup\", ¿deben por defecto mostrar las barras de desplazamiento?';
$string['status'] = 'Estatus';
$string['statusinfo'] = 'Las ventanas \"popup\", ¿deben por defecto mostrar la barra de estado?';
$string['toolbar'] = 'Mostrar la barra de herramientas';
$string['toolbarinfo'] = 'Las ventanas \"popup\", ¿deben por defecto mostrar la barra de herramientas?';
$string['viewertypeopen'] = 'C&oacute;mo se ha de abrir el visor';
$string['viewertypeopeninfo'] = 'C&oacute;mo quieres que se le abra al alumno el visor';
$string['width'] = 'Ancho';
$string['widthinfo'] = 'Esta preferencia ajusta la anchura por defecto del marco o ventana';

// ********** END
?>