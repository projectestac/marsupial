<?PHP 

$string['consumeerror'] = 'Some error ocurred during the process';
$string['consumefinish'] = 'Process finish correctly.';
$string['consumetitle'] = 'Books Structure downloader';
$string['consumewait'] = 'Running the downloader, this process may take some time, please wait...';
$string['downloadbookstructures'] = 'Download books structures';
$string['error_authentication'] = 'Authentication error: Code: ';
$string['error_code_0'] = 'Unexpected error.';
$string['error_code_-1'] = 'Failed to make the dynamic URL.';
$string['error_code_-2'] = 'The license code is invalid.';
$string['error_code_-3'] = 'The product Isbn is not valid.';
$string['error_code_-4'] = 'The license has expired.';
$string['error_code_-101'] = 'Incorrect authentication. The user requesting access to this
Web service method is not correct.';
$string['error_code_-102'] = 'Incorrect authentication. The user requesting access to this
web service method has insufficient permissions.';
$string['exit'] = 'Exit';
$string['loading'] = 'Loading, please wait...';
$string['urlmoreinfo'] = 'For more information: <a href="$a" target="_blank">click here</a>';
$string['noactivity'] = 'Activity not found.';
$string['nobooks'] = 'No books received';
$string['nobookid'] = 'Book not found.';
$string['nocredentials'] = 'Credentials not found.';
$string['nopublisher'] = 'Publisher not found.';
$string['nounit'] = 'Unit not found.';
$string['rcommon'] = 'Remote resource manager';
$string['selectpublisher'] = 'Select a publisher...';
$string['selectpublisherdescription'] = 'To download all the book structures it is necessary to select a publisher';
//XTEC ********** AFEGIT -> Text string for students roles settings
//2011.05.16 @mmartinez
$string['teacherroles'] = 'Teacher roles';
$string['teacherrolesinfo'] = 'Roles that will be authenticated as a teacher. The rest will be authenticated as a student';
//********** FI
$string['centernotfound'] = 'Code center (CFG->center) not found in config.php';

?>