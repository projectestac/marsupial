<?PHP 

$string['consumeerror'] = 'S\'ha produ&iuml;t algun error durant el proc&eacute;s';
$string['consumefinish'] = 'Proc&eacute;s finalitzat correctament.';
$string['consumetitle'] = 'Desc&agrave;rrega de l\'estructura dels llibres dels prove&iuml;dors de continguts';
$string['consumewait'] = 'Descarregant l\'estructura dels llibres. <br>Aquest proc&eacute;s pot portar alguns minuts.<br>Si us plau, esperi...';
$string['downloadbookstructures'] = 'Descarrega l\'estructura dels llibres';
$string['error_authentication'] = 'Error d\'autenticaci&oacute, codi: ';
$string['error_code_0'] = 'Error inesperat.';
$string['error_code_-1'] = 'Error al realitzar la URL din&agrave;mica.';
$string['error_code_-2'] = 'El codi de llicencia no es v&agrave;lid.';
$string['error_code_-3'] = 'El Isbn del producte no es v&agrave;lid.';
$string['error_code_-4'] = 'La llicencia ha expirat.';
$string['error_code_-101'] = 'Autenticaci&oacute; incorrecta. L\'usuari que sol&middot;licitat acc&eacute;s a aquest
m&egrave;tode del servei web no es correcte.';
$string['error_code_-102'] = 'Autenticaci&oacute; incorrecta. L\'usuari que sol&middot;licita acc&eacute;s a aquest
m&egrave;tode del servei web no te permisos suficients.';
$string['exit'] = 'Surt';
$string['loading'] = 'Descarregant. Si us plau esperi...';
$string['urlmoreinfo'] = 'Per a m&eacute;s informaci&oacute;: <a href="$a" target="_blank">click aqu&iacute;</a>';
$string['noactivity'] = 'Activitat no trobada';
$string['nobooks'] = 'No s\'ha rebut cap llibre';
$string['nobookid'] = 'Llibre no trobat';
$string['nocredentials'] = 'Credencials per accedir al llibre no trobades';
$string['nopublisher'] = 'Prove&iuml;dor de continguts no trobat';
$string['nounit'] = 'Unitat no trobada';
$string['rcommon'] = 'Recursos remots';
$string['selectpublisher'] = 'Seleccioneu un prove&iuml;dor de continguts...';
//XTEC ********** AFEGIT -> Text string for students roles settings
//2011.05.16 @mmartinez
$string['teacherroles'] = 'Rols del professorat';
$string['teacherrolesinfo'] = 'Rols que s\'autenticaran a les editorials com a usuari professor/a. La resta s\'autenticaran com a estudiants';
//********** FI
$string['centernotfound'] = 'Codi de centre (CFG->center) no trobat al fitxer de configuraci&oacute; (config.php)';

?>