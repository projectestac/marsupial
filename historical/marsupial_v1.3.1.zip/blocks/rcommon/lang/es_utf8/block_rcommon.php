<?PHP 

$string['consumeerror'] = 'Ocurrio alg&uacute;n error durante el proceso.';
$string['consumefinish'] = 'Proceso finalizado correctamente.';
$string['consumetitle'] = 'Descargador de la estructura de libros';
$string['consumewait'] = 'Descargando, el proceso puede durar unos minutos, por favor espere...';
$string['downloadbookstructures'] = 'Descargar estructura de libros';
$string['error_authentication'] = 'Error de autenticaci&oacute;n, c&oacute;digo: ';
$string['error_code_0'] = 'Error inesperado.';
$string['error_code_-1'] = 'Error al realizar la URL din&aacute;mica.';
$string['error_code_-2'] = 'El c&oacute;digo de licencia no es v&aacute;lido.';
$string['error_code_-3'] = 'El Isbn del producto no es v&aacute;lido.';
$string['error_code_-4'] = 'La licencia ha expirado.';
$string['error_code_-101'] = 'Autenticaci&oacute;n incorrecta. El usuario que solicita acceso a este
m&eacute;todo del servicio Web no es correcto.';
$string['error_code_-102'] = 'Autenticaci&oacute;n incorrecta. El usuario que solicita acceso a este
m&eacute;todo del servicio Web no tiene permisos suficientes.';
$string['exit'] = 'Salir';
$string['loading'] = 'Descargando, por favor espere...';
$string['urlmoreinfo'] = 'Para m&aacute;s informaci&oacute;n: <a href="$a" target="_blank">click aqu&iacute;</a>';
$string['noactivity'] = 'Actividad no encontrada.';
$string['nobooks'] = 'No se han recibido libros';
$string['nobookid'] = 'Libro no encontrado.';
$string['nocredentials'] = 'Credenciales no encontradas.';
$string['nopublisher'] = 'Editor no encontrado.';
$string['nounit'] = 'Unidad no encontrada.';
$string['rcommon'] = 'Remote resource manager';
$string['selectpublisher'] = 'Seleccione un editor...';
//XTEC ********** AFEGIT -> Text string for students roles settings
//2011.05.16 @mmartinez
$string['teacherroles'] = 'Roles profesor';
$string['teacherrolesinfo'] = 'Roles que se autenticar&aacute;n en las editoriales como usuario profesor. El resto se autenticar&aacute;n como estudiante';
//********** FI
$string['centernotfound'] = "C&oacute;digo de centro (CFG->center) no encontrado en config.php";

?>