<?php

require_once('../../config.php');
require_once('locallib.php');

$id = required_param('id', PARAM_INT);        // course

if (($course = get_record('course', 'id', $id)) === false) {
    error('Course ID is incorrect');
}

require_course_login($course);

$strrcontent = "Remote content";//

/// Print the header

$navlinks = array(
    array(
        'name' => $strrcontent,
        'link' => '',
        'type' => 'activity'
    )
);

$navigation = build_navigation($navlinks);

print_header_simple(
    $strrcontent,
    '',
    $navigation,
    '',
    '',
    true,
    '',
    navmenu($course)
);

/// Get all the appropriate data

if (($rcontents = get_all_instances_in_course('rcontent', $course)) === false) {
    notice('There are no rcontents', '../../course/view.php?id=' . $course->id);
    die;
}

/// Print the list of instances (your module will probably extend this)

$strname = get_string('name');
$strsummary = get_string('summary');
$strreport = get_string('report','rcontent');
$table->data = array();

if ($course->format == 'weeks') {
    $table->head = array(get_string('week'), $strname, $strsummary,$strreport);
    $table->align = array('center', 'left');
}
else if ($course->format == 'topics') {
    $table->head = array(get_string('topic'), $strname, $strsummary, $strreport);
    $table->align = array('center', 'left', 'left', 'left');
}
else {
    $table->head = array($strname, $strreport);
    $table->align = array('left', 'left', 'left');
}

//XTEC ********** AFEGIT -> Add pagination
//2011.05.18 @mmartinez
$page       = optional_param("page",0);
$limit      = $CFG->rcontent_registersperreportpage;
$count      = count($rcontents);
$startindex = ($limit*$page);
//********** FI

//XTEC ********** MODIFICAT -> Just show the registers of one page
//2011.05.18 @mmatinez
for($i=$startindex;$i<($startindex+$limit);$i++) {
	if ($i > count($rcontents)-1){
		break;
	}
	$rcontent = $rcontents[$i];
//********* ORIGINAL
//foreach ($rcontents as $rcontent) {
//********* FI
	$context = get_context_instance(CONTEXT_MODULE, $rcontent->coursemodule);
    $report = '&nbsp;';
    $reportshow = '&nbsp;';
    
    if (has_capability('mod/rcontent:viewreport', $context)) {
        $trackedusers = rcontent_get_count_users($rcontent->id, $rcontent->groupingid, $context);
        if ($trackedusers > 0) {
            $reportshow = '<a href="report.php?id='.$rcontent->coursemodule.'">'.get_string('viewalluserreports','rcontent',$trackedusers).'</a></div>';
        } else {
            $reportshow = get_string('noreports','rcontent');
        }
    } else if (has_capability('mod/rcontent:viewscores', $context)) {
    	require_once('locallib.php');
        $report = rcontent_grade_user($rcontent, $USER->id);
        $reportshow = get_string('score','rcontent').": ".$report;
    }
    
    if (!$rcontent->visible) {
        //Show dimmed if the mod is hidden
        $link = '<a class="dimmed" href="' . $CFG->wwwroot . '/mod/rcontent/view.php?id=' . $rcontent->coursemodule . '">' . $rcontent->name . '</a>';
    }
    else {
        //Show normal if the mod is visible
        $link = '<a href="view.php?id=' . $rcontent->coursemodule . '">' . $rcontent->name . '</a>';
    }

    if ($course->format == 'weeks' || $course->format == 'topics') {
        array_push($table->data, array($rcontent->section, $link, $rcontent->summary,$reportshow));
    }
    else {
        array_push($table->data, array($link));
    }
}

print_heading($strrcontent);
//XTEC ********** AFEGIT -> Add pagination
//2011.05.18 @mmartinez
print_paging_bar($count, $page, $limit, "index.php?id=$id&amp;", "page", false);
//********** FI

print_table($table);

//XTEC ********** AFEGIT -> Add pagination
//2011.05.18 @mmartinez
print_paging_bar($count, $page, $limit, "index.php?id=$id&amp;", "page", false);
//********** FI

/// Finish the page

print_footer($course);