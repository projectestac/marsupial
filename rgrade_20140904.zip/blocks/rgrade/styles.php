
.block_rgrade fieldset {
	border: 0;
}

.block_rgrade label span {
	display: block;
	margin-top: 4px;
}
