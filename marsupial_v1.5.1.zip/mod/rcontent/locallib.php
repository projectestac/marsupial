<?php

define('RCONTENT_HIGHESTATTEMPT', '0');
define('RCONTENT_AVERAGEATTEMPT', '1');
define('RCONTENT_FIRSTATTEMPT', '2');
define('RCONTENT_LASTATTEMPT', '3');

define('RCONTENT_NOFRAME', '0');
define('RCONTENT_YESWITHFRAME', '1');
define('RCONTENT_YESWITHOUTFRAME', '2');

require_once("$CFG->dirroot/mod/rcontent/lib.php");

/**
 * Returns an array of the array of what grade options
 *
 * @return array an array of what grade options
 */
function rcontent_get_what_grade_array(){
    return array (RCONTENT_HIGHESTATTEMPT => get_string('highestattempt', 'rcontent'),
                  RCONTENT_AVERAGEATTEMPT => get_string('averageattempt', 'rcontent'),
                  RCONTENT_FIRSTATTEMPT => get_string('firstattempt', 'rcontent'),
                  RCONTENT_LASTATTEMPT => get_string('lastattempt', 'rcontent'));
}

function rcontent_get_frame_type_array(){
	return array(RCONTENT_NOFRAME => get_string('keepnavigationvisibleno','rcontent'),
	             RCONTENT_YESWITHFRAME => get_string('keepnavigationvisibleyesframe','rcontent'),
	             RCONTENT_YESWITHOUTFRAME => get_string('keepnavigationvisibleyesobject','rcontent'));
}

/**
 * Check the grades available for the request activity
 * @param int $rcontentid -> ID of the rcontent
 * @param int $groupingid -> ID of the group
 * @return int -> count of grades
 */
// MARSUPIAL ********** MODIFICAT -> Filter by status
// 2011.08.31 @mmartinez
function rcontent_get_count_users($rcontentid, $groupingid=null, $context, $filter = '') {
// ********** ORIGINAL
//function rcontent_get_count_users($rcontentid, $groupingid=null, $context) {
// ********** FI	

    global $CFG, $USER;
	
    //test when the user role is studen and just count his grades
    if($user_rol=array_values(get_user_roles($context))){
    	if ($user_rol[0]->shortname=='student'){
    		$sql="SELECT st.id FROM {$CFG->prefix}rcontent_grades st
	                WHERE st.rcontentid = $rcontentid AND st.userid=$USER->id";
// MARSUPIAL ********** AFEGIT -> Filter by status
// 2011.08.31 @mmartinez
            if ($filter != ''){
                $sql .= " AND st.status = '{$filter}'";
            }
// ********** FI
    		if(count_records_sql($sql)>0){
    			return 1;
    		}
    	}else{
    		if (!empty($CFG->enablegroupings) && !empty($groupingid)) {
	        	$sql = "SELECT COUNT(DISTINCT st.userid)
	                FROM {$CFG->prefix}rcontent_grades st
	                    INNER JOIN {$CFG->prefix}groups_members gm ON st.userid = gm.userid
	                    INNER JOIN {$CFG->prefix}groupings_groups gg ON gm.groupid = gg.groupid
	                WHERE st.rcontentid = $rcontentid AND gg.groupingid = $groupingid";
// MARSUPIAL ********** AFEGIT -> Filter by status
// 2011.08.31 @mmartinez
		            if ($filter != ''){
		                $sql .= " AND st.status = '{$filter}'";
		            }
// ********** FI
	    	} else {
	       		$sql = "SELECT COUNT(DISTINCT st.userid)
	                FROM {$CFG->prefix}rcontent_grades st
	                WHERE st.rcontentid = $rcontentid";
// MARSUPIAL ********** AFEGIT -> Filter by status
// 2011.08.31 @mmartinez
	       		if ($filter != ''){
	                $sql .= " AND st.status = '{$filter}'";
	       		}
// ********** FI
	    	}
	    	return(count_records_sql($sql));
    	}
    }
    return 0;
}

/**
 * Check the score of the request user for the request activity
 * @param $rcontent int -> ID of the activity
 * @param $userid int -> ID of the user
 * @param $time int -> datetime
 * @return int -> the score for that user
 */
function rcontent_grade_user($rcontent, $userid, $from='') {
    
	//take the global grade for the given activity
    $sql="userid=$userid AND rcontentid=$rcontent->id AND unitid=$rcontent->unitid AND activityid=$rcontent->activityid";
    if(!$grade=get_records_select('rcontent_grades',$sql)){
        return 0;
    }
    
	$grade = current($grade);
	
	$lastattempt = rcontent_get_last_attempt($rcontent->id, $userid);
    if($grade->maxattempts != 0 && $lastattempt >= $grade->maxattempts){
        $lastattempt = $grade->maxattempts;
    }
    
    switch ($rcontent->whatgrade) {
        case RCONTENT_FIRSTATTEMPT:
            $grade=rcontent_grade_user_attempt($rcontent->id, $userid, 1, $grade->unitid, $grade->activityid);
            if($from!='gradebook')
                return $grade->justgrade.' '.$grade->range;
            else
                return $grade->justgrade;
        break;
        case RCONTENT_LASTATTEMPT:
            $grade=rcontent_grade_user_attempt($rcontent->id, $userid, $lastattempt, $grade->unitid, $grade->activityid);
            if($from!='gradebook')
                return $grade->justgrade.' '.$grade->range;
            else
                return $grade->justgrade;
        break;
        case RCONTENT_HIGHESTATTEMPT:
            $maxscore = 0;
            $attempttime = 0;
            for ($attempt = 1; $attempt <= $lastattempt; $attempt++) {
                $attemptgrade = rcontent_grade_user_attempt($rcontent->id, $userid, $attempt, $grade->unitid, $grade->activityid);
                $maxscore = ($attemptgrade->justgrade > $maxscore) ? $attemptgrade->justgrade: $maxscore;
            }
            if($from!='gradebook')
                return $maxscore.' '.$attemptgrade->range;
            else
                return $attemptgrade->justgrade;
        break;
        case RCONTENT_AVERAGEATTEMPT:
            $sumscore = 0;
            for ($attempt = 1; $attempt <= $lastattempt; $attempt++) {
                $attemptgrade = rcontent_grade_user_attempt($rcontent->id, $userid, $attempt, $grade->unitid, $grade->activityid);
                $sumscore += $attemptgrade->justgrade;
            }
            if ($lastattempt > 0) {
                $score = $sumscore / $lastattempt;
            } else {
                $score = 0;
            }
            if($from!='gradebook')
                return $score.' '.$attemptgrade->range;
            else
                return $attemptgrade->justgrade;
        break;
    }	
}

/**
 * Check the grade comment for the request user and activity
 * @param int $rcontent
 * @param int $userid
 * @return string
 */
function rcontent_grade_user_comments($rcontent, $userid){

	switch ($rcontent->whatgrade) {
		case RCONTENT_FIRSTATTEMPT: 
			if (!$comment=get_record_select('rcontent_grades',"rcontentid=$rcontent->id AND userid=$userid AND unitid=$rcontent->unitid AND activityid=$rcontent->activityid AND attempt=1",'comments')){
			    return '';
			}
		    break;
		default:
			$lastattempt = rcontent_get_last_attempt($rcontent->id, $userid);
			if(!$comment=get_record_select('rcontent_grades',"rcontentid=$rcontent->id AND userid=$userid AND unitid=$rcontent->unitid AND activityid=$rcontent->activityid AND attempt=$lastattempt",'comments')){
				return '';
			}
			
	}
	return $comment->comments;
}


/**
* Delete grades and grades_details for selected users
* @param int $rcontentid list of attempts that need to be deleted
* @param int $userid ID of Scorm
* @return bool -> true deleted all responses, false failed deleting an attempt - stopped here
*/
function rcontent_delete_responses($attemptids,$rcontentid) {
    
    if(!is_array($attemptids) || empty($attemptids)) {
        return false;
    }

    foreach($attemptids as $num => $attemptid) {
        if(empty($attemptid)) {
            unset($attemptids[$num]);
        }
    }

    foreach($attemptids as $attempt) {
        $keys = explode(':', $attempt);
        if (count($keys) == 2) {
            $userid = clean_param($keys[0], PARAM_INT);
            $attemptid = clean_param($keys[1], PARAM_INT);
            if (!$userid || !$attemptid || !rcontent_delete_attempt($userid, $rcontentid, $attemptid)) {
                    return false;
            }
        } else {
            return false;
        }
    }
    return true;
}

/**
* Delete grades and details for selected users
* @param int $userid ID of User
* @param int $rcontentid ID of Scorm
* @param int $attemptid user attempt that need to be deleted
* @return bool true suceeded
*/
function rcontent_delete_attempt($userid, $rcontentid, $attemptid) {
    if (!delete_records('rcontent_grades', 'userid', $userid, 'rcontentid', $rcontentid, 'attempt', $attemptid)){
    	return false;
    }
    if (!delete_records('rcontent_grades_details', 'userid', $userid, 'rcontentid', $rcontentid, 'attempt', $attemptid)){
    	return false;
    }
    return true;
}

/**
 * Gets user info required to display the table of rcontent results for report.php
 * @param int $userid
 * @return array -> firstname, lastname and user picture
 */
function rcontent_get_user_data($userid) {

    return get_record('user','id',$userid,'','','','','firstname, lastname, picture');
}

/**
 * Find the last attempt number for the given user id and scorm id
 * @param int $rcontentid
 * @param int $userid
 */
function rcontent_get_last_attempt($rcontentid, $userid) {
    if ($lastattempt = get_record('rcontent_grades', 'userid', $userid, 'rcontentid', $rcontentid, '', '', 'max(attempt) as a')) {
        if (empty($lastattempt->a)) {
            return '1';
        } else {
            return $lastattempt->a;
        }
    }
}

/** Find the start and finish time for a a given attempt
 * @param int $rcontentid SCORM Id
 * @param int $userid User Id
 * @param int $attemt Attempt Id
 * @return object start and finsh time EPOC secods
 */
function rcontent_get_attempt_runtime($rcontentid, $userid, $attempt=1, $unitid='', $activityid='') {

    $timedata = new object();
    $timedata->start='';
    $timedata->finish='';
    $sql = "userid=$userid AND rcontentid=$rcontentid AND attempt=$attempt";
    $sql.=($unitid!='')?" AND unitid=$unitid":" AND unitid=0";
    $sql.=($activityid!='')?" AND activityid=$activityid":" AND activityid=0";
    if($tracks = get_records_select('rcontent_grades',"$sql ORDER BY timemodified ASC")){
    
	    if ($tracks) {
	        $tracks = array_values($tracks);
	    }
// MARSUPIAL ************ MODIFICAT -> Fixed bug when startime is empty
// 2011.10.31 @mmartinez
	   if ($tracks && !empty($tracks[0]->starttime) && $tracks[0]->starttime > 0) {
// *********** ORIGINAL
           //if ($tracks) {
// *********** FI	        
           $timedata->start = userdate($tracks[0]->starttime, get_string('strftimedaydatetime'));
	    }
	    else {
	        $timedata->start = '';
	    }
	    if ($tracks[0]->totaltime!='') {
	        $segundos= $tracks[0]->totaltime;
	        $horas=intval($segundos/3600);
	        $segundos=$segundos-($horas*3600);
	        $horas=($horas<10)?'0'.$horas:$horas;
	        $minutos=intval($segundos/60);
	        $minutos=($minutos<10)?'0'.$minutos:$minutos;
	        $segundos=$segundos-($minutos*60);
	        $segundos=($segundos<10)?'0'.$segundos:$segundos;
	        $timedata->finish=$horas.":".$minutos.":".$segundos;
	    }
	    else {
	        $timedata->finish = '00:00:00';        
	    }
    }
    
    return $timedata;
}

/** Find the start and finsh time for a a given detail attempt
 * @param int $rcontentid SCORM Id
 * @param int $userid User Id
 * @param int $attemt Attempt Id
 * @return object start and finsh time EPOC secods
 */
function rcontent_details_get_attempt_runtime($id) {

    $timedata = new object();
    $timedata->start='';
    $timedata->finish='';
    
    $tracks = get_record('rcontent_grades_details', 'id', $id);
   
   if ($tracks && $tracks->starttime > 0) {
        $timedata->start = userdate($tracks->starttime, get_string('strftimedaydatetime'));
    }
    else {
        $timedata->start = '';
    }
    
    if ($tracks->totaltime != '' && $tracks->totaltime > 0) {
        $segundos= $tracks->totaltime;
        $horas=intval($segundos/3600);
        $segundos=$segundos-($horas*3600);
        $horas=($horas<10)?'0'.$horas:$horas;
        $minutos=intval($segundos/60);
        $minutos=($minutos<10)?'0'.$minutos:$minutos;
        $segundos=$segundos-($minutos*60);
        $segundos=($segundos<10)?'0'.$segundos:$segundos;
        $timedata->finish=$horas.":".$minutos.":".$segundos;
    }
    else {
        $timedata->finish = '';        
    }
    
    return $timedata;
}

/**
 * Find the activity grade for a given user and attempt
 * @param int $rcontentid
 * @param int $userid
 * @param int $attempt
 * @param int $unitid
 * @param int $activityid
 * @return string grade(mingrade/maxgrade)
 */
//MARSUPIAL ********* MODIFICAR -> Added new parameter idgrade to search just for it
//2011.05.20 @mmartinez
function rcontent_grade_user_attempt($rcontentid, $userid, $attempt=1, $unitid='', $activityid='', $idgrade = '') {
	global $CFG;
		
    //take the grade of the activity
    if (!empty($idgrade)){
    	$sql = "id = $idgrade";
    } else {
//********* ORIGINAL
//function rcontent_grade_user_attempt($rcontentid, $userid, $attempt=1, $unitid='', $activityid='') {
//********** FI

        $sql ="userid=$userid AND rcontentid=$rcontentid AND attempt=$attempt";
        $sql .=($unitid!='')?" AND unitid=$unitid":" AND unitid=0";
        $sql .=($activityid!='')?" AND activityid=$activityid":" AND activityid=0";
    }
    
    $grade=get_records_select("rcontent_grades", $sql);
    $return = new stdClass();
    $return->id='';
    $return->grade='';
    $return->justgrade='';
    $return->range='';
    $return->maxattempts='';
//MARSUPIAL ************ MODIFICAT -> Call the new function to calculate parent status
//2011.05.17 @mmartinez
    $return->status = rcontent_grade_calculate_status($rcontentid, $userid, $attempt, $unitid, $activityid);
//************ ORIGINAL
    //$return->status='';
//*********** FI
    $return->url='';
    $return->justurl='';
    $return->comments='';
    $return->justcomments='&nbsp;';
    $return->fullcomments='&nbsp;';
    
    if ($grade) {
//MARSUPIAL ********** ADDED -> Calculate grade in fact of the option selected in activity configuration
//2011.06.07 @mmartinez
    	if (count($grade) > 1){
	    	if ($rcon = get_record("rcontent", "id", $rcontentid)){ 
	        	switch ($rcon->whatgrade){
	        		case RCONTENT_FIRSTATTEMPT:
	        			$grade_sql = get_record_sql("SELECT * FROM {$CFG->prefix}rcontent_grades WHERE {$sql} AND timecreated = (SELECT MIN(timecreated) FROM {$CFG->prefix}rcontent_grades WHERE ".$sql.")");
	        			$grade = $grade_sql;
	        		break;
	        		case RCONTENT_LASTATTEMPT:
	        			$grade_sql = get_record_sql("SELECT * FROM {$CFG->prefix}rcontent_grades WHERE {$sql} AND timecreated = (SELECT MAX(timecreated) FROM {$CFG->prefix}rcontent_grades WHERE ".$sql.")");
	        			$grade = $grade_sql;
	        		break;
	        		case RCONTENT_HIGHESTATTEMPT:
	        			$grade_sql = get_record_sql("SELECT * FROM {$CFG->prefix}rcontent_grades WHERE {$sql} AND grade=(SELECT max(grade) as grade FROM {$CFG->prefix}rcontent_grades WHERE ".$sql.")", true);
	        			$grade = $grade_sql;
	        		break;
	        		case RCONTENT_AVERAGEATTEMPT:
	        		 	$grade_sql = get_record_sql("SELECT round(avg(grade)) as grade FROM {$CFG->prefix}rcontent_grades WHERE ".$sql);
	        		 	$grade = array_pop($grade);
	        		 	$grade->grade = $grade_sql->grade;
	        		break;
	        	}
	        }
    	} else {
    		$grade = array_pop($grade);
    	}
//********** FI

        //$grade = array_pop($grade);
        $return->id=$grade->id;
        $return->grade='<div id="rcontent_grade_'.$userid.'_'.$grade->id.'">'.$grade->grade.'</div>';
        $return->justgrade=$grade->grade;
        $return->range="($grade->mingrade-$grade->maxgrade)";
        $return->maxattempts='('.$grade->maxattempts.')';
//MARSUPIAL ************ ELIMINAT -> Take out becouse we calculate it before
//2011.05.17 @mmartinez
        //$return->status=$grade->status;
//*********** FI
        if($grade->urlviewresults!=""){
        	$httptest='';
        	if (strpos($grade->urlviewresults,'http://')===false){
        		$httptest='http://';
        	}
            $return->url='<a href="'.$httptest.$grade->urlviewresults.'" target="_blank">'.get_string('view','rcontent').'</a> &middot;';
            $return->justurl='<a href="'.$httptest.$grade->urlviewresults.'" target="_blank">'.get_string('view','rcontent').'</a>';
        }
        if($grade->comments!=""){
        	$return->comments='<div id="rcontent_comments_'.$userid.'_'.$grade->id.'">';
        	if(strlen($grade->comments)>30){
        	     $return->comments.='<span title="'.$grade->comments.'">'.substr($grade->comments,0,27).'...</span>';
        	     $return->justcomments='<span title="'.$grade->comments.'">'.substr($grade->comments,0,27).'...</span>';	
        	}else{
        		$return->comments.=$grade->comments;
        		$return->justcomments=$grade->comments;
        	}
        	$return->comments.='</div>';
        	$return->fullcomments=$grade->comments;
        } else {
        	$return->comments='<div id="rcontent_comments_'.$userid.'_'.$grade->id.'"></div>';
        }
    }
	
	return $return;
}

/**
 * Find the activity detail grade for a given user and attempt
 * @param int $rcontent
 * @param int $userid
 * @param int $attempt
 * @param int $time
 * @return string grade(mingrade/maxgrade)
 */
function rcontent_grade_details_user_attempt($id, $rcontentid, $userid, $attempt=1, $time=false, $unitid='', $activityid='') {
    
    $grade=get_record('rcontent_grades_details', 'id', $id);
    
    $return = new stdClass();
    $return->grade='';
    $return->range='';
    $return->maxattemps='';
    $return->weight='';
    $return->url='';
    $return->description='';
    $return->totalweight='';
    
    if ($grade) {
        $return->grade=$grade->grade;
        $return->range="($grade->mingrade-$grade->maxgrade)";
        $return->maxattempts='('.$grade->maxattempts.')';
        $return->weight=$grade->weight;
        if($grade->urlviewresults!=""){
        	$httptest='';
            if (strpos($grade->urlviewresults,'http://')===false){
        		$httptest='http://';
        	}
            $return->url='<a href="'.$httptest.$grade->urlviewresults.'" target="_blank">'.get_string('view','rcontent').'</a>';
        }
        if($grade->description!=""){
        	if(strlen($grade->description)>30){
        	     $return->description='<span title="'.$grade->description.'">'.substr($grade->description,0,27).'...</span>';	
        	}else{
        		$return->description=$grade->description;
        	}
        }
        //take the sumweight for the parent 
        $sql="userid=$userid AND rcontentid=$rcontentid AND attempt=$attempt";
        $sql.=($unitid!='')?" AND unitid=$unitid":" AND unitid=0";
        $sql.=($activityid!='')?" AND activityid=$activityid":" AND activityid=0";
        
    	if($totalweight=get_records_select('rcontent_grades',$sql)){
    		foreach ($totalweight as $tw){
    		    $return->totalweight='('.$tw->sumweights.')';
    		}
    	}    		
    }
	
	return $return;
}

//MARSUPIAL ************ AFEGIT -> New function to calculate the parent status depending off the child status
//2011.05.17 @mmartinez
function rcontent_grade_calculate_status ($rcontentid, $userid, $attempt=1, $unitid = 0, $activityid = 0){
	
	global $CFG;
	//echo "unit: $unitid, activity: $activityid<br>";  //just  for debug
	//get status of the given grade
	$sql_general  = "userid=$userid AND rcontentid=$rcontentid AND attempt=$attempt";
    $sql_unit     = ($unitid != '')? " AND unitid=$unitid" : " AND unitid=0";
    $sql_activity = ($activityid != '')? " AND activityid=$activityid" : " AND activityid=0";  
    
    if ($status = get_records_select('rcontent_grades',$sql_general.$sql_unit.$sql_activity)){
	    $status = array_pop($status);
	    $orig_status = $status->status;
    } else {
    	$orig_status = $status->status = "";
    }
    $return = array('', $orig_status);
	//check if we are calculating for a activity
	if ($activityid != 0){
	   $return[0] = $status->status;
	   //print_r($return); echo "<br>"; //just for debug mode
	   return $return;
	}
	    
	//check if we are calculating for a unit
	if ($unitid != 0 && $activityid == 0) {
		//search for activities status if unit status is diferrent to POR_CORREGIR
		if ($status->status != "POR_CORREGIR"){
//MARSUPIAL ************* MODIFICAT -> All to str lower
//2011.10.26 @mmartinez
            $sql = "SELECT * FROM {$CFG->prefix}rcontent_grades u WHERE u.userid=$userid AND u.rcontentid=$rcontentid AND u.attempt=$attempt AND u.unitid=$unitid AND u.activityid<>0 AND u.status='POR_CORREGIR'";
//*********** ORIGINAL
		    //$sql = "SELECT * FROM {$CFG->prefix}RCONTENT_GRADES U WHERE U.USERID=$userid AND U.RCONTENTID=$rcontentid AND U.ATTEMPT=$attempt AND U.UNITID=$unitid AND U.ACTIVITYID<>0 AND U.STATUS='POR_CORREGIR'";
//*********** FI
			if (count_records_sql($sql)>0){
				$return[0] = "POR_CORREGIR";
				return $return;
			}
			$return[0] = $status->status;
			
		} else {
			$return[0] = $status->status;
		}
		
	}	
	//check if we are calculating for a book
	if ($unitid == 0 && $activityid == 0){
		//search for units status
		if ($status->status != "POR_CORREGIR"){
		    $sql = "SELECT COUNT(b.status) FROM {$CFG->prefix}rcontent_grades b WHERE b.userid=$userid AND b.rcontentid=$rcontentid AND b.attempt=$attempt AND b.unitid=0 AND b.activityid=0 AND (b.status = 'POR_CORREGIR' OR EXISTS (SELECT * FROM {$CFG->prefix}rcontent_grades u WHERE u.userid=$userid AND u.rcontentid=$rcontentid AND u.unitid <> 0 AND u.status='POR_CORREGIR' AND u.attempt=b.attempt))";
			if (count_records_sql($sql)>0){
				$return[0] = "POR_CORREGIR";
				return $return;
			}
			$return[0] = $status->status;
			
		} else {
			$return[0] = $status->status;
		}
		
	}
    //print_r($return); echo "<br>";  //just for debug
	return $return;
    
}
//************ FI

/**
 * Direct update of a grade instance from the view report
 * @return bool -> if ok true else false
 */
function rcontent_update_grade_instance(){
	
    if (!$feedback = data_submitted()) {      // No incoming data?
	    return false;
    }
    
	if (!empty($feedback->cancel)) {          // User hit cancel button
        return false;
    }
    
    if(!is_numeric($feedback->txtgrade)){
    	echo '<script type="text/javascript">'."\n<!--\n";
        echo 'history.back();';
        echo "\n-->\n</script>";
    	return false;
    }    
    
    $update=new stdClass();
    $update->id=$feedback->idgrade;
    $update->grade=round($feedback->txtgrade,2);
    $update->comments=$feedback->submissioncomment;
    
//MARSUPIAL ********* AFEGIT -> Update the modified date
//2011.05.19 @mmartinez
    $update->timemodified = time();
//********* FI
    
//MARSUPIAL ********** AFEGIT -> Update status but just if the actuall status is POR_CORREGIR
//2011.05.18 @mmartinez
    //retrieve data of that registry from db to know if status must be update or not
    if ($rdata = get_record_select('rcontent_grades', 'id = '.$feedback->idgrade, 'status')){
    	if ($rdata->status = "POR_CORREGIR"){
    		$update->status = "CORREGIDO";
    	}
    }
//************ FI

    if (!$return=update_record('rcontent_grades', $update)) {
        return false;
    }
    
    if(strlen($feedback->submissioncomment)>30){
        $comment='<span title="'.$feedback->submissioncomment.'">'.substr($feedback->submissioncomment,0,27).'...</span>';	
    }else{
    	$comment=$feedback->submissioncomment;
    }
    
    /// Run some Javascript to try and update the parent page
    echo '<script type="text/javascript">'."\n<!--\n";
        echo 'opener.document.getElementById("rcontent_grade_'.$feedback->user.'_'.$feedback->idgrade.'").innerHTML="'.round($feedback->txtgrade,2).'";';
        echo 'opener.document.getElementById("rcontent_comments_'.$feedback->user.'_'.$feedback->idgrade.'").innerHTML=\''.$comment.'\';';
    echo "\n-->\n</script>";
    
    
    //Update gradebook
    $rcontent=get_record('rcontent','id',$feedback->rcontentid);
    rcontent_update_grades($rcontent,$feedback->user);
    
    add_to_log($feedback->course, 'rcontent', 'update grades', 'report.php?id='.$feedback->id.'&user='.$feedback->user, 
        $feedback->user, $feedback->id);
    
    return true;
}

/**
 * Load level list from bd table mdl_rcommon_level
 * @return array with the loaded data
 */
function rcontent_level_list(){
    global $CFG;
    $return[0]='- '.get_string('level','rcontent').' -';

//********** MODIFICAT MARSUPIAL - levels with books and level code added to the list
    
    $sql = "SELECT * FROM {$CFG->prefix}rcommon_level
            WHERE id IN (Select distinct levelid from {$CFG->prefix}rcommon_books where upper(format) = 'WEBCONTENT')";

    if($records = get_records_sql($sql))
    {
        foreach($records as $r){
            $return[$r->id] = $r->code." - ".$r->name ;
        }
    }
//**********    
    return $return; 
}

/**
 * Load all books from bd rcommon_books
 * @param int $levelid -> ID of the level
 * @param string $from -> to response in a format or other
 * @return array -> (id=>name)
 */
function rcontent_isbn_list($levelid='',$from='ajax'){
    global $CFG;
    if($from=='updateform'){
    	$return[0]='- '.get_string('isbn','rcontent').' -';
    }else{
    	$return[]=array('id'=>0,'name'=>'- '.get_string('isbn','rcontent').' -');
    }
	if($levelid!=""){
		$sql="SELECT rb.*, rp.name as publiname FROM {$CFG->prefix}rcommon_books rb
		    INNER JOIN {$CFG->prefix}rcommon_publisher rp ON rb.publisherid=rp.id
		    WHERE rb.levelid='".$levelid."' AND rb.format='webcontent'
		    ORDER BY rb.name ASC";
        if($records=get_records_sql($sql)){
    	    foreach($records as $r){
    	    	if($from=='updateform'){
    	    		$return[$r->id]=$r->name." ($r->publiname)";
    	    	}else{
    	    	    $return[]=array('id'=>$r->id,'name'=>$r->name." ($r->publiname)");
    	    	}
    	    }
    	    
        }
	}
    return $return; 
}

/**
 * Load the units of a determinate book from bd rcommon_books_units
 * @param $bookid int -> ID of the book
 * @param $from string -> for select the array structure of the response 
 * @return array -> (id=>name)
 */
function rcontent_unit_list($bookid='',$from='ajax'){
	global $CFG;
	if($from=='updateform'){
		$return[0]='- '.get_string('unit','rcontent').' -';
	}else{
		$return[]=array('id'=>0,'name'=>'- '.get_string('unit','rcontent').' -');
	}
	if($bookid!=""){
        if($records=get_records('rcommon_books_units','bookid',$bookid,'sortorder')){
    	    foreach($records as $r){
    	    	if($from=='updateform'){
    	    		$return[$r->id]=$r->name;
    	    	}else{
    	    	    $return[]=array('id'=>$r->id,'name'=>$r->name);
    	    	}
    	    }
    	    
        }
	}
	return $return;
}

/**
 * Load the activities of a determinated unit from bd rcommon_books_activities
 * @param $bookid int -> ID of the book
 * @param $unitid int -> ID of the unit
 * @param $from string -> for select the array structure of the response
 * @return array -> (id=>name)
 */
function rcontent_activity_list($bookid='',$unitid='',$from='ajax'){
	global $CFG;
	if($from=='updateform'){
		$return[0]='- '.get_string('activity','rcontent').' -';
	}else{
		$return[]=array('id'=>0,'name'=>'- '.get_string('activity','rcontent').' -');
	}
	if($bookid!=""&&$unitid!=""){
	    if($records=get_records_sql("SELECT * FROM {$CFG->prefix}rcommon_books_activities WHERE bookid='".$bookid."' AND unitid='".$unitid."' ORDER BY sortorder ASC")){
	    	foreach($records as $r){
	    	if($from=='updateform'){
    	    		$return[$r->id]=$r->name;
    	    	}else{
    	    	    $return[]=array('id'=>$r->id,'name'=>$r->name);
    	    	}
	    	}
	    	
	    }
	}
	return $return;
}

/**
 * Insert a note into the error log of the bd rcommond_errors_log
 * @param $action string -> 
 * @param $bookis int ->
 * @param $cmid int ->
 * @return int -> ID of the new entry in the log or false if failds
 */
function rcontent_insert_error_log($action, $bookid, $cmid=0){
	
	global $USER, $COURSE;
	
	$tmp = new stdClass();
	$tmp->time      =  time();
	$tmp->userid    =  $USER->id;
	$tmp->ip        =  $_SERVER['REMOTE_ADDR'];
	$tmp->course    =  $COURSE->id;
	$tmp->module    =  "rcontent";
	$tmp->cmid      =  $cmid;
	$tmp->action    =  $action;
	$tmp->url       =  $_SERVER['REQUEST_URI'];
	$tmp->info      =  "Bookid: ".$bookid.", Text: ".get_string($action,'rcontent');
	
	return insert_record("rcommon_errors_log",$tmp);
}
?>