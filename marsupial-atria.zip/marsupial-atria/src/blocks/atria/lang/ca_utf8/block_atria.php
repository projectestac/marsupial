<?php
$string['Atria'] = 'Àtria';
$string['atriasyncbtn'] = 'Sincronització amb Àtria';
$string['atriasyncbtnadmin'] = 'Administració d\'Àtria';
?>
