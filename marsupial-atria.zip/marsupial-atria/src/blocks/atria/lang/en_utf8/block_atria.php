<?php
$string['Atria'] = 'Àtria';
$string['atriasyncbtn'] = 'Sync with Àtria';
$string['atriasyncbtnadmin'] = 'Àtria Administration';
?>
