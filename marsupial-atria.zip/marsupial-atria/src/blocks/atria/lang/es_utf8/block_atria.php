<?php
$string['Atria'] = 'Àtria';
$string['atriasyncbtn'] = 'Sincronización con Àtria';
$string['atriasyncbtnadmin'] = 'Administración de Àtria';
?>
